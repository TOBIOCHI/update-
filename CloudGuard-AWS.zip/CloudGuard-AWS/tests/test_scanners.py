"""
Offline tests. `moto` imitates AWS inside the computer, so these tests create
deliberately misconfigured resources and check that each rule fires (and does
not fire on the secure ones) without touching a real AWS account.

Run:  python -m pytest -q
"""
import json
import os
from datetime import datetime, timedelta, timezone

import boto3
import pytest
from moto import mock_aws

from scanner.rules import RULES, finding
from scanner.s3_scanner import effective_bpa
from scanner.ec2_scanner import scan_security_groups, scan_ebs
from scanner.iam_scanner import scan_iam, document_is_full_admin
from scanner.logging_scanner import scan_cloudtrail
from scanner.engine import run_scan

REGION = "us-east-1"


@pytest.fixture(autouse=True)
def fake_credentials(monkeypatch):
    for k, v in {"AWS_ACCESS_KEY_ID": "testing", "AWS_SECRET_ACCESS_KEY": "testing",
                 "AWS_DEFAULT_REGION": REGION}.items():
        monkeypatch.setenv(k, v)
    monkeypatch.delenv("AWS_PROFILE", raising=False)


def rules(findings):
    return {(f["rule_id"], f["resource"]) for f in findings}


# ---------- rule catalogue ----------
def test_every_rule_uses_three_level_severity():
    assert {r["severity"] for r in RULES.values()} <= {"HIGH", "MEDIUM", "LOW"}


def test_finding_shape():
    item = finding("S3-01", "bucket-a")
    assert item["severity"] == "HIGH" and item["resource"] == "bucket-a" and item["recommendation"]


# ---------- S3 ----------
def test_account_level_block_public_access_protects_bucket():
    on = dict.fromkeys(("BlockPublicAcls", "IgnorePublicAcls", "BlockPublicPolicy", "RestrictPublicBuckets"), True)
    assert all(effective_bpa(on, {}).values())          # account on, bucket unset -> protected
    assert not all(effective_bpa({}, {}).values())       # both unset -> not protected


# ---------- EC2 ----------
@mock_aws
def test_open_ssh_and_rdp_detected_but_restricted_ssh_is_not():
    ec2 = boto3.client("ec2", region_name=REGION)
    vpc = ec2.create_vpc(CidrBlock="10.0.0.0/16")["Vpc"]["VpcId"]

    def sg(name, port, cidr):
        gid = ec2.create_security_group(GroupName=name, Description=name, VpcId=vpc)["GroupId"]
        ec2.authorize_security_group_ingress(GroupId=gid, IpPermissions=[
            {"IpProtocol": "tcp", "FromPort": port, "ToPort": port, "IpRanges": [{"CidrIp": cidr}]}])
        return gid

    ssh = sg("cg-open-ssh", 22, "0.0.0.0/0")
    rdp = sg("cg-open-rdp", 3389, "0.0.0.0/0")
    safe = sg("cg-ssh-office-only", 22, "203.0.113.10/32")

    found = scan_security_groups(ec2)[0]
    ids = {(f["rule_id"], f["resource"].split()[0]) for f in found}
    assert ("EC2-01", ssh) in ids
    assert ("EC2-02", rdp) in ids
    assert not any(r[1] == safe for r in ids)


@mock_aws
def test_all_traffic_rule_counts_as_open_ssh():
    ec2 = boto3.client("ec2", region_name=REGION)
    vpc = ec2.create_vpc(CidrBlock="10.1.0.0/16")["Vpc"]["VpcId"]
    gid = ec2.create_security_group(GroupName="cg-all", Description="all", VpcId=vpc)["GroupId"]
    ec2.authorize_security_group_ingress(GroupId=gid, IpPermissions=[
        {"IpProtocol": "-1", "IpRanges": [{"CidrIp": "0.0.0.0/0"}]}])
    found = {(f["rule_id"], f["resource"].split()[0]) for f in scan_security_groups(ec2)[0]}
    assert ("EC2-01", gid) in found and ("EC2-02", gid) in found


@mock_aws
def test_ebs_default_encryption_and_unencrypted_volume():
    ec2 = boto3.client("ec2", region_name=REGION)
    plain = ec2.create_volume(AvailabilityZone=f"{REGION}a", Size=1)["VolumeId"]
    secure = ec2.create_volume(AvailabilityZone=f"{REGION}a", Size=1, Encrypted=True)["VolumeId"]
    found = rules(scan_ebs(ec2, REGION)[0])
    assert ("ENC-01", f"Region {REGION}") in found
    assert ("ENC-02", plain) in found
    assert ("ENC-02", secure) not in found

    ec2.enable_ebs_encryption_by_default()
    assert ("ENC-01", f"Region {REGION}") not in rules(scan_ebs(ec2, REGION)[0])


# ---------- IAM ----------
def test_full_admin_policy_document():
    assert document_is_full_admin({"Statement": [{"Effect": "Allow", "Action": "*", "Resource": "*"}]})
    assert not document_is_full_admin({"Statement": [{"Effect": "Allow", "Action": "s3:Get*", "Resource": "*"}]})
    assert not document_is_full_admin({"Statement": [{"Effect": "Deny", "Action": "*", "Resource": "*"}]})


@mock_aws
def test_iam_rules():
    iam = boto3.client("iam")
    iam.create_user(UserName="cg-nomfa-user")
    iam.create_login_profile(UserName="cg-nomfa-user", Password="Str0ng!Passw0rd-x")
    iam.create_user(UserName="cg-api-only")                      # no console password -> not IAM-02
    iam.create_user(UserName="cg-admin-user")
    iam.put_user_policy(UserName="cg-admin-user", PolicyName="everything",
                        PolicyDocument=json.dumps({"Version": "2012-10-17",
                                                   "Statement": [{"Effect": "Allow", "Action": "*", "Resource": "*"}]}))
    iam.create_user(UserName="cg-readonly-user")
    iam.put_user_policy(UserName="cg-readonly-user", PolicyName="read",
                        PolicyDocument=json.dumps({"Version": "2012-10-17",
                                                   "Statement": [{"Effect": "Allow", "Action": "s3:Get*", "Resource": "*"}]}))
    iam.create_access_key(UserName="cg-api-only")

    session = boto3.Session(region_name=REGION)
    errors = []
    future = datetime.now(timezone.utc) + timedelta(days=120)   # pretend 120 days have passed
    found = scan_iam(session, errors, now=future)[0]
    ids = {(f["rule_id"], f["resource"].split(" key")[0]) for f in found}

    assert ("IAM-02", "user/cg-nomfa-user") in ids
    assert ("IAM-02", "user/cg-api-only") not in ids
    assert ("IAM-03", "user/cg-admin-user") in ids
    assert ("IAM-03", "user/cg-readonly-user") not in ids
    assert ("IAM-04", "user/cg-api-only") in ids
    assert not errors, errors


# ---------- CloudTrail ----------
@mock_aws
def test_cloudtrail_missing_then_logging():
    session = boto3.Session(region_name=REGION)
    errors = []
    assert ("LOG-01", f"Region {REGION}") in rules(scan_cloudtrail(session, REGION, errors)[0])

    boto3.client("s3", region_name=REGION).create_bucket(Bucket="cg-trail-logs")
    ct = boto3.client("cloudtrail", region_name=REGION)
    ct.create_trail(Name="cg-trail", S3BucketName="cg-trail-logs", EnableLogFileValidation=True)
    ct.start_logging(Name="cg-trail")
    found = rules(scan_cloudtrail(session, REGION, errors)[0])
    assert ("LOG-01", f"Region {REGION}") not in found
    assert ("LOG-02", "trail/cg-trail") not in found


# ---------- whole engine ----------
@mock_aws
def test_engine_runs_all_modules_and_times_scan():
    session = boto3.Session(region_name=REGION)
    account = boto3.client("sts").get_caller_identity()["Account"]
    result = run_scan(session, account, REGION)
    assert [m["module"] for m in result["modules"]] == ["S3", "EC2 and EBS", "IAM", "CloudTrail"]
    assert result["duration_seconds"] >= 0
    # an empty account still has no root MFA and no trail in moto
    assert {"IAM-01", "LOG-01", "ENC-01"} <= {f["rule_id"] for f in result["findings"]}


@mock_aws
def test_s3_public_policy_and_private_bucket():
    from scanner.s3_scanner import scan_s3
    s3 = boto3.client("s3", region_name=REGION)
    account = boto3.client("sts").get_caller_identity()["Account"]
    s3.create_bucket(Bucket="cg-test-private")
    s3.put_public_access_block(Bucket="cg-test-private", PublicAccessBlockConfiguration=dict.fromkeys(
        ("BlockPublicAcls", "IgnorePublicAcls", "BlockPublicPolicy", "RestrictPublicBuckets"), True))
    s3.create_bucket(Bucket="cg-test-public-policy")
    s3.put_bucket_policy(Bucket="cg-test-public-policy", Policy=json.dumps({
        "Version": "2012-10-17",
        "Statement": [{"Effect": "Allow", "Principal": "*", "Action": "s3:GetObject",
                       "Resource": "arn:aws:s3:::cg-test-public-policy/*"}]}))
    errors = []
    found = rules(scan_s3(boto3.Session(region_name=REGION), account, errors)[0])
    assert ("S3-03", "cg-test-public-policy") in found
    assert not any(r[1] == "cg-test-private" for r in found)
    # moto may not implement GetBucketPolicyStatus; if it does, S3-01 must fire
    if not any("cg-test-public-policy" in e for e in errors):
        assert ("S3-01", "cg-test-public-policy") in found
