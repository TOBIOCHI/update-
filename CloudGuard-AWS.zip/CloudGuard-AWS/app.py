import csv
import io

from flask import Flask, render_template, redirect, url_for, flash, Response, abort

from config import Config
from scanner.aws_client import get_session, get_account_identity
from scanner.engine import run_scan
from database.db import init_db, save_scan, get_latest_scan, get_scan, list_scans, get_findings

app = Flask(__name__)
app.config.from_object(Config)

init_db()


def _counts(findings):
    counts = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}
    for item in findings:
        counts[item["severity"]] = counts.get(item["severity"], 0) + 1
    return counts


@app.route("/")
def index():
    latest = get_latest_scan()
    findings = get_findings(latest["id"]) if latest else []
    return render_template("dashboard.html", scan=latest, findings=findings, counts=_counts(findings),
                           history=list_scans())


@app.route("/scan/<int:scan_id>")
def view_scan(scan_id):
    scan = get_scan(scan_id) or abort(404)
    findings = get_findings(scan_id)
    return render_template("dashboard.html", scan=scan, findings=findings, counts=_counts(findings),
                           history=list_scans())


@app.route("/scan/<int:scan_id>/export.csv")
def export_csv(scan_id):
    """Export findings so they can be compared with the ground truth and with Prowler (evaluation/)."""
    get_scan(scan_id) or abort(404)
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["rule_id", "resource", "severity", "category", "title", "description", "recommendation"])
    for f in get_findings(scan_id):
        writer.writerow([f["rule_id"], f["resource"], f["severity"], f.get("category") or "",
                         f["title"], f["description"], f["recommendation"]])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=cloudguard_scan_{scan_id}.csv"})


@app.post("/scan")
def start_scan():
    try:
        session = get_session()
        identity = get_account_identity(session)
        region = session.region_name or Config.AWS_REGION
        result = run_scan(session, identity["Account"], region)
        scan_id = save_scan(identity["Account"], region, result)
        msg = (f"Scan {scan_id} finished in {result['duration_seconds']} s: "
               f"{len(result['findings'])} findings across {result['resources_checked']} checked items.")
        if result["errors"]:
            msg += f" {len(result['errors'])} check(s) could not run; see the list under the findings."
        flash(msg, "warning" if result["errors"] else "success")
    except Exception as exc:
        # Do not expose credentials or full request details in the browser.
        app.logger.exception("AWS scan failed")
        flash(f"Scan could not be completed: {friendly_error(exc)}", "danger")
    return redirect(url_for("index"))


def friendly_error(exc):
    from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
    if isinstance(exc, (NoCredentialsError, PartialCredentialsError)):
        return "AWS credentials were not found or are incomplete. Configure an AWS CLI profile first."
    if isinstance(exc, ClientError):
        code = exc.response.get("Error", {}).get("Code", "AWS API error")
        if code in ("AccessDenied", "AccessDeniedException", "UnauthorizedOperation"):
            return "The configured AWS identity lacks permission for one or more read-only scan operations."
        return f"AWS returned {code}. Check the AWS region, account permissions and connectivity."
    return "Check the terminal for diagnostic details."


if __name__ == "__main__":
    # Local development only. Do not expose Flask's development server to the internet.
    app.run(host="127.0.0.1", port=5000, debug=False)
