import json
import sqlite3
from datetime import datetime, timezone

from config import Config


def connect():
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id TEXT NOT NULL,
                scanned_at TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS findings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER NOT NULL,
                rule_id TEXT NOT NULL,
                resource TEXT NOT NULL,
                severity TEXT NOT NULL,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                recommendation TEXT NOT NULL,
                FOREIGN KEY(scan_id) REFERENCES scans(id)
            )
        """)
        # Columns added after the starter version. Older databases are upgraded in place.
        _add_column(conn, "scans", "region", "TEXT")
        _add_column(conn, "scans", "duration_seconds", "REAL")
        _add_column(conn, "scans", "resources_checked", "INTEGER")
        _add_column(conn, "scans", "modules_json", "TEXT")
        _add_column(conn, "scans", "errors_json", "TEXT")
        _add_column(conn, "findings", "category", "TEXT")


def _add_column(conn, table, column, kind):
    cols = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}
    if column not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {kind}")


def save_scan(account_id, region, result):
    with connect() as conn:
        cur = conn.execute(
            "INSERT INTO scans(account_id, scanned_at, region, duration_seconds, resources_checked, modules_json, errors_json) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (account_id, datetime.now(timezone.utc).isoformat(timespec="seconds"), region,
             result["duration_seconds"], result["resources_checked"],
             json.dumps(result["modules"]), json.dumps(result["errors"])),
        )
        scan_id = cur.lastrowid
        conn.executemany("""
            INSERT INTO findings (scan_id, rule_id, category, resource, severity, title, description, recommendation)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, [(scan_id, f["rule_id"], f["category"], f["resource"], f["severity"], f["title"],
               f["description"], f["recommendation"]) for f in result["findings"]])
    return scan_id


def _scan_row(row):
    if not row:
        return None
    scan = dict(row)
    scan["modules"] = json.loads(scan.get("modules_json") or "[]")
    scan["errors"] = json.loads(scan.get("errors_json") or "[]")
    return scan


def get_latest_scan():
    with connect() as conn:
        return _scan_row(conn.execute("SELECT * FROM scans ORDER BY id DESC LIMIT 1").fetchone())


def get_scan(scan_id):
    with connect() as conn:
        return _scan_row(conn.execute("SELECT * FROM scans WHERE id=?", (scan_id,)).fetchone())


def list_scans(limit=20):
    with connect() as conn:
        rows = conn.execute("""
            SELECT s.id, s.scanned_at, s.region, s.duration_seconds, s.resources_checked,
                   SUM(f.severity='HIGH') AS high, SUM(f.severity='MEDIUM') AS medium, SUM(f.severity='LOW') AS low,
                   COUNT(f.id) AS total
            FROM scans s LEFT JOIN findings f ON f.scan_id = s.id
            GROUP BY s.id ORDER BY s.id DESC LIMIT ?
        """, (limit,)).fetchall()
        return [dict(r) for r in rows]


def get_findings(scan_id):
    with connect() as conn:
        rows = conn.execute(
            "SELECT * FROM findings WHERE scan_id=? "
            "ORDER BY CASE severity WHEN 'HIGH' THEN 1 WHEN 'MEDIUM' THEN 2 ELSE 3 END, rule_id, resource",
            (scan_id,),
        ).fetchall()
        return [dict(row) for row in rows]
