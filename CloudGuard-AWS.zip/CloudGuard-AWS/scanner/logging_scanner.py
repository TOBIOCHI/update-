"""
Read-only CloudTrail checks for the selected Region:
  LOG-01  no trail is logging in this Region
  LOG-02  log file validation disabled on a trail
"""
from botocore.exceptions import ClientError

from scanner.rules import finding


def scan_cloudtrail(session, region, errors):
    ct = session.client("cloudtrail", region_name=region)
    findings, checked = [], 0
    try:
        trails = ct.describe_trails(includeShadowTrails=True).get("trailList", [])
    except ClientError as exc:
        errors.append(f"CloudTrail: {exc.response.get('Error', {}).get('Code', exc)}")
        return findings, checked

    logging_trails = 0
    for trail in trails:
        checked += 1
        name = trail.get("Name")
        try:
            status = ct.get_trail_status(Name=trail.get("TrailARN", name))
            if status.get("IsLogging"):
                logging_trails += 1
        except ClientError as exc:
            errors.append(f"CloudTrail trail {name}: {exc.response.get('Error', {}).get('Code', exc)}")
        if not trail.get("LogFileValidationEnabled", False):
            findings.append(finding("LOG-02", f"trail/{name}"))

    if logging_trails == 0:
        findings.append(finding("LOG-01", f"Region {region}", f"{len(trails)} trail(s) found, none logging."))
    return findings, checked + 1
