import boto3
from config import Config

def get_session():
    """Use the standard AWS credential chain; never embed keys in source code."""
    if Config.AWS_PROFILE:
        return boto3.Session(profile_name=Config.AWS_PROFILE, region_name=Config.AWS_REGION)
    return boto3.Session(region_name=Config.AWS_REGION)

def get_account_identity(session):
    return session.client("sts").get_caller_identity()
