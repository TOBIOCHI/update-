"""
Read-only IAM checks (IAM is global, so the Region does not matter):
  IAM-01  root account without MFA
  IAM-02  console user without MFA
  IAM-03  user, group or role with full admin ("*" on "*")
  IAM-04  active access key older than 90 days
"""
from datetime import datetime, timezone
from urllib.parse import unquote
import json

from botocore.exceptions import ClientError

from scanner.rules import finding

ADMIN_POLICY_ARN = "arn:aws:iam::aws:policy/AdministratorAccess"
KEY_MAX_AGE_DAYS = 90


def _as_list(x):
    return x if isinstance(x, list) else [x]


def document_is_full_admin(doc):
    """True if any Allow statement grants Action '*' on Resource '*'."""
    if isinstance(doc, str):
        doc = json.loads(unquote(doc))
    for st in _as_list(doc.get("Statement", [])):
        if st.get("Effect") != "Allow":
            continue
        actions = _as_list(st.get("Action", []))
        resources = _as_list(st.get("Resource", []))
        if "*" in actions and "*" in resources:
            return True
    return False


def _admin_customer_policies(iam):
    """ARNs of customer-managed policies (attached somewhere) whose default version is full admin."""
    arns = set()
    for page in iam.get_paginator("list_policies").paginate(Scope="Local", OnlyAttached=True):
        for pol in page["Policies"]:
            ver = iam.get_policy_version(PolicyArn=pol["Arn"], VersionId=pol["DefaultVersionId"])
            if document_is_full_admin(ver["PolicyVersion"]["Document"]):
                arns.add(pol["Arn"])
    return arns | {ADMIN_POLICY_ARN}


def _check_identity(iam, kind, name, admin_arns):
    """kind is 'user', 'group' or 'role'. Returns a reason string if the identity has full admin."""
    attached = getattr(iam, f"list_attached_{kind}_policies")(**{f"{kind.capitalize()}Name": name})["AttachedPolicies"]
    for pol in attached:
        if pol["PolicyArn"] in admin_arns:
            return f"Attached policy {pol['PolicyName']}"
    for pol_name in getattr(iam, f"list_{kind}_policies")(**{f"{kind.capitalize()}Name": name})["PolicyNames"]:
        doc = getattr(iam, f"get_{kind}_policy")(**{f"{kind.capitalize()}Name": name, "PolicyName": pol_name})["PolicyDocument"]
        if document_is_full_admin(doc):
            return f"Inline policy {pol_name}"
    return None


def scan_iam(session, errors, now=None):
    iam = session.client("iam")
    now = now or datetime.now(timezone.utc)
    findings, checked = [], 0

    # IAM-01 root MFA
    try:
        summary = iam.get_account_summary()["SummaryMap"]
        checked += 1
        if not summary.get("AccountMFAEnabled", 0):
            findings.append(finding("IAM-01", "root account"))
    except ClientError as exc:
        errors.append(f"IAM account summary: {exc.response.get('Error', {}).get('Code', exc)}")

    try:
        admin_arns = _admin_customer_policies(iam)
    except ClientError as exc:
        errors.append(f"IAM policies: {exc.response.get('Error', {}).get('Code', exc)}")
        admin_arns = {ADMIN_POLICY_ARN}

    # Users: IAM-02, IAM-03, IAM-04
    for page in iam.get_paginator("list_users").paginate():
        for user in page["Users"]:
            name = user["UserName"]
            checked += 1
            try:
                try:
                    iam.get_login_profile(UserName=name)
                    has_console = True
                except ClientError as exc:
                    if exc.response.get("Error", {}).get("Code") != "NoSuchEntity":
                        raise
                    has_console = False
                if has_console and not iam.list_mfa_devices(UserName=name)["MFADevices"]:
                    findings.append(finding("IAM-02", f"user/{name}"))

                reason = _check_identity(iam, "user", name, admin_arns)
                if reason:
                    findings.append(finding("IAM-03", f"user/{name}", reason))

                for key in iam.list_access_keys(UserName=name)["AccessKeyMetadata"]:
                    age = (now - key["CreateDate"]).days
                    if key["Status"] == "Active" and age > KEY_MAX_AGE_DAYS:
                        findings.append(finding("IAM-04", f"user/{name} key {key['AccessKeyId'][-4:]}", f"Key age {age} days"))
            except ClientError as exc:
                errors.append(f"IAM user {name}: {exc.response.get('Error', {}).get('Code', exc)}")

    # Groups and roles: IAM-03 only
    for kind, pager, key, field in (("group", "list_groups", "Groups", "GroupName"),
                                     ("role", "list_roles", "Roles", "RoleName")):
        for page in iam.get_paginator(pager).paginate():
            for item in page[key]:
                name = item[field]
                # Roles created and managed by AWS itself are not the customer's configuration.
                if kind == "role" and item.get("Path", "/").startswith("/aws-service-role/"):
                    continue
                checked += 1
                try:
                    reason = _check_identity(iam, kind, name, admin_arns)
                    if reason:
                        findings.append(finding("IAM-03", f"{kind}/{name}", reason))
                except ClientError as exc:
                    errors.append(f"IAM {kind} {name}: {exc.response.get('Error', {}).get('Code', exc)}")

    return findings, checked
