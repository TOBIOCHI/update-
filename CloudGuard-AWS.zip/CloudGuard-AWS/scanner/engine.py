"""
Rule engine: runs every scanner module, times the scan and collects errors.

The scan time recorded here is the "detection response time" (Td = Te - Ts)
defined in the evaluation metrics.
"""
import time

from scanner.s3_scanner import scan_s3
from scanner.ec2_scanner import scan_ec2
from scanner.iam_scanner import scan_iam
from scanner.logging_scanner import scan_cloudtrail
from scanner.rules import SEVERITY_ORDER


def run_scan(session, account_id, region):
    errors, findings, modules = [], [], []
    start = time.perf_counter()

    steps = [
        ("S3", lambda: scan_s3(session, account_id, errors)),
        ("EC2 and EBS", lambda: scan_ec2(session, region, errors)),
        ("IAM", lambda: scan_iam(session, errors)),
        ("CloudTrail", lambda: scan_cloudtrail(session, region, errors)),
    ]
    for name, fn in steps:
        t0 = time.perf_counter()
        try:
            f, checked = fn()
        except Exception as exc:  # a module failing must not stop the others
            errors.append(f"{name} module failed: {type(exc).__name__}: {exc}")
            f, checked = [], 0
        findings += f
        modules.append({"module": name, "checked": checked, "findings": len(f),
                        "seconds": round(time.perf_counter() - t0, 3)})

    findings.sort(key=lambda x: (SEVERITY_ORDER[x["severity"]], x["rule_id"], x["resource"]))
    return {
        "findings": findings,
        "errors": errors,
        "modules": modules,
        "resources_checked": sum(m["checked"] for m in modules),
        "duration_seconds": round(time.perf_counter() - start, 3),
    }
