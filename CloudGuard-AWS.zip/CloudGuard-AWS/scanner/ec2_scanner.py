"""
Read-only EC2 checks for the selected Region:
  EC2-01 / EC2-02  security group open to the internet on SSH (22) / RDP (3389)
  ENC-01           EBS encryption by default turned off
  ENC-02           unencrypted EBS volume
"""
from botocore.exceptions import ClientError

from scanner.rules import finding

ADMIN_PORTS = {22: "EC2-01", 3389: "EC2-02"}
OPEN_V4, OPEN_V6 = "0.0.0.0/0", "::/0"


def _rule_covers_port(perm, port):
    """True if an inbound rule covers `port` over TCP (or all protocols)."""
    proto = str(perm.get("IpProtocol"))
    if proto == "-1":  # all traffic
        return True
    if proto not in ("tcp", "6"):
        return False
    lo, hi = perm.get("FromPort"), perm.get("ToPort")
    return lo is not None and hi is not None and lo <= port <= hi


def _open_to_world(perm):
    v4 = any(r.get("CidrIp") == OPEN_V4 for r in perm.get("IpRanges", []))
    v6 = any(r.get("CidrIpv6") == OPEN_V6 for r in perm.get("Ipv6Ranges", []))
    return v4 or v6


def scan_security_groups(ec2):
    findings, checked = [], 0
    for page in ec2.get_paginator("describe_security_groups").paginate():
        for sg in page["SecurityGroups"]:
            checked += 1
            label = f"{sg['GroupId']} ({sg.get('GroupName', '')})"
            for port, rule_id in ADMIN_PORTS.items():
                if any(_open_to_world(p) and _rule_covers_port(p, port) for p in sg.get("IpPermissions", [])):
                    findings.append(finding(rule_id, label, f"Inbound rule allows port {port} from anywhere."))
    return findings, checked


def scan_ebs(ec2, region):
    findings, checked = [], 1
    if not ec2.get_ebs_encryption_by_default().get("EbsEncryptionByDefault", False):
        findings.append(finding("ENC-01", f"Region {region}"))
    for page in ec2.get_paginator("describe_volumes").paginate():
        for vol in page["Volumes"]:
            checked += 1
            if not vol.get("Encrypted", False):
                findings.append(finding("ENC-02", vol["VolumeId"], f"Size {vol.get('Size')} GiB, state {vol.get('State')}"))
    return findings, checked


def scan_ec2(session, region, errors):
    ec2 = session.client("ec2", region_name=region)
    findings, checked = [], 0
    for name, fn in (("security groups", lambda: scan_security_groups(ec2)), ("EBS", lambda: scan_ebs(ec2, region))):
        try:
            f, n = fn()
            findings += f
            checked += n
        except ClientError as exc:
            errors.append(f"EC2 {name}: {exc.response.get('Error', {}).get('Code', exc)}")
    return findings, checked
