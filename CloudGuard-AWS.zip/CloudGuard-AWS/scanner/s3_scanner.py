"""
Read-only S3 checks: S3-01 public bucket policy, S3-02 public ACL, S3-03 Block Public Access.

Changes from the starter version:
- Reads the ACCOUNT-level Block Public Access setting as well. A bucket is only
  reported under S3-03 if a setting is off at BOTH account and bucket level.
  The starter flagged buckets as MEDIUM even when the account-level setting
  protected them, which would have raised the false positive rate.
- An error on one bucket no longer stops the whole scan. It is recorded in
  `errors` and the scan moves to the next bucket.
"""
from botocore.exceptions import ClientError

from scanner.rules import finding

BPA_KEYS = ("BlockPublicAcls", "IgnorePublicAcls", "BlockPublicPolicy", "RestrictPublicBuckets")
PUBLIC_GROUPS = {
    "http://acs.amazonaws.com/groups/global/AllUsers",
    "http://acs.amazonaws.com/groups/global/AuthenticatedUsers",
}


def _code(exc):
    return exc.response.get("Error", {}).get("Code", "")


def get_account_bpa(session, account_id, errors):
    """Return the account-level Block Public Access settings (all False if none are set)."""
    try:
        cfg = session.client("s3control").get_public_access_block(AccountId=account_id)
        return cfg.get("PublicAccessBlockConfiguration", {})
    except ClientError as exc:
        if _code(exc) in ("NoSuchPublicAccessBlockConfiguration", "NoSuchConfiguration"):
            return {}
        errors.append(f"S3 account Block Public Access: {_code(exc) or exc}")
        return {}


def get_bucket_bpa(s3, name):
    try:
        return s3.get_public_access_block(Bucket=name).get("PublicAccessBlockConfiguration", {})
    except ClientError as exc:
        if _code(exc) in ("NoSuchPublicAccessBlockConfiguration", "NoSuchConfiguration"):
            return {}
        raise


def effective_bpa(account_cfg, bucket_cfg):
    """A setting is effectively on if it is on at account level OR bucket level."""
    return {k: bool(account_cfg.get(k)) or bool(bucket_cfg.get(k)) for k in BPA_KEYS}


def scan_s3(session, account_id, errors):
    s3 = session.client("s3")
    findings, checked = [], 0
    account_bpa = get_account_bpa(session, account_id, errors)

    for bucket in s3.list_buckets().get("Buckets", []):
        name = bucket["Name"]
        checked += 1
        try:
            bpa = effective_bpa(account_bpa, get_bucket_bpa(s3, name))
            off = [k for k, v in bpa.items() if not v]
            if off:
                findings.append(finding("S3-03", name, "Settings off at both account and bucket level: " + ", ".join(off)))

            try:
                status = s3.get_bucket_policy_status(Bucket=name).get("PolicyStatus", {})
                if status.get("IsPublic"):
                    findings.append(finding("S3-01", name, "AWS reports the bucket policy as public."))
            except ClientError as exc:
                if _code(exc) not in ("NoSuchBucketPolicy", "NoSuchPolicy"):
                    raise

            try:
                grants = s3.get_bucket_acl(Bucket=name).get("Grants", [])
                public = [g for g in grants if g.get("Grantee", {}).get("URI") in PUBLIC_GROUPS]
                if public:
                    perms = ", ".join(sorted({g.get("Permission", "?") for g in public}))
                    findings.append(finding("S3-02", name, f"Public group has: {perms}"))
            except ClientError as exc:
                if _code(exc) != "AccessControlListNotSupported":
                    raise
        except ClientError as exc:
            errors.append(f"S3 bucket {name}: {_code(exc) or exc}")

    return findings, checked
