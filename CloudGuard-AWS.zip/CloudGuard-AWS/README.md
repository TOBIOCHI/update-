# CloudGuard – AWS Misconfiguration Detection Tool

A local, read-only Python/Flask tool that checks one AWS account against 13 security rules based on the CIS AWS Foundations Benchmark, rates each finding High, Medium or Low, and shows how to fix it.

Final-year project: *Design and Implementation of a Cloud Misconfiguration Detection Tool* (Cybersecurity, Miva Open University).

## What it checks

| Rule | Severity | Check |
|---|---|---|
| S3-01 | High | Bucket policy allows public access |
| S3-02 | High | Bucket ACL grants access to AllUsers / AuthenticatedUsers |
| S3-03 | Medium | Block Public Access not fully on (account **and** bucket level both checked) |
| EC2-01 | High | Security group allows SSH (22) from 0.0.0.0/0 or ::/0 |
| EC2-02 | High | Security group allows RDP (3389) from 0.0.0.0/0 or ::/0 |
| IAM-01 | High | Root account has no MFA |
| IAM-02 | Medium | IAM user with a console password but no MFA |
| IAM-03 | High | User, group or role with "*" actions on "*" resources |
| IAM-04 | Low | Active access key older than 90 days |
| LOG-01 | Medium | No CloudTrail trail logging in the scanned Region |
| LOG-02 | Low | CloudTrail log file validation disabled |
| ENC-01 | Medium | EBS encryption by default off in the scanned Region |
| ENC-02 | Medium | Unencrypted EBS volume |

S3 has encrypted all new objects automatically since January 2023, so encryption is checked on EBS instead of S3.

## Project layout

```
app.py                     Flask web app: dashboard, scan history, CSV export
config.py                  Reads .env (profile, region, secret key)
scanner/rules.py           The rule catalogue: severity, title and fix advice for every rule
scanner/engine.py          Runs all modules, times the scan, collects errors
scanner/s3_scanner.py      S3-01..S3-03
scanner/ec2_scanner.py     EC2-01, EC2-02, ENC-01, ENC-02
scanner/iam_scanner.py     IAM-01..IAM-04
scanner/logging_scanner.py LOG-01, LOG-02
database/db.py             SQLite storage of scans and findings
evaluation/evaluate.py     Computes TP/FP/FN/TN, accuracy, precision, recall, F1, FPR
tests/test_scanners.py     Offline tests using moto (no real AWS account needed)
```

## Windows setup

1. Install Python 3.11 or newer and AWS CLI v2.
2. In PowerShell, inside this folder:

   ```powershell
   py -m venv venv
   .\venv\Scripts\Activate.ps1          # or venv\Scripts\activate.bat in Command Prompt
   python -m pip install --upgrade pip
   pip install -r requirements-dev.txt
   ```

3. Run the offline tests first. They need no AWS account:

   ```powershell
   python -m pytest -q
   ```

4. Create a read-only audit user in your own AWS account (see "AWS permissions"), then:

   ```powershell
   aws configure --profile cloudguard-audit
   aws sts get-caller-identity --profile cloudguard-audit
   ```

5. Copy `.env.example` to `.env` and set `AWS_PROFILE=cloudguard-audit`, `AWS_REGION` (the Region where your test resources are) and a long random `FLASK_SECRET_KEY`.
6. `python app.py`, open http://127.0.0.1:5000 and click **Run full scan**.

## AWS permissions

Attach the AWS managed policy **SecurityAudit** (read-only) to a dedicated IAM user or role. Never use root credentials or AdministratorAccess for scanning, never commit `.env` or keys to Git, and never send credentials to anyone.

## Evaluation (Chapter 4)

1. Create the deliberately misconfigured resources and the secure "control" resources listed in your test plan.
2. Copy `evaluation/ground_truth_template.csv` to `evaluation/ground_truth.csv` and edit it so each row says which rule should FAIL or PASS for each test resource.
3. Run a scan, click **Export CSV**, then:

   ```powershell
   python evaluation/evaluate.py evaluation/ground_truth.csv cloudguard_scan_1.csv
   ```

4. Run Prowler on the same account, map its matching checks to the rule IDs above in a CSV with `rule_id,resource` columns, and run `evaluate.py` on that file too. Compare the two sets of results in Chapter 4.

## Limitations

- Educational prototype, not a certified security product. It does not change AWS resources.
- Scans one Region per run (plus global IAM and S3).
- A clean scan does not prove the account is secure; it only means these 13 rules passed.
- Do not run against an account you are not authorised to assess.
