import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

class Config:
    SECRET_KEY = os.getenv("FLASK_SECRET_KEY", "change-this-local-development-key")
    DATABASE_PATH = os.getenv("DATABASE_PATH", str(BASE_DIR / "cloudguard.db"))
    AWS_PROFILE = os.getenv("AWS_PROFILE") or None
    AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
