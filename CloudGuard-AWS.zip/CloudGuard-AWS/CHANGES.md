# Changes from the starter version

Date: 11 November 2026. Changes prepared with AI assistance (Claude) and reviewed by the student. Copy this into the project logbook and commit it to GitHub as its own commit so the history shows what changed and when.

## Fixes to the existing S3 check

1. **Account-level Block Public Access is now read** (`s3control.get_public_access_block`). The starter flagged every bucket without a bucket-level setting, even when the account-level setting already protected it. Those would have been false positives in Chapter 4.
2. **One failing bucket no longer stops the scan.** Errors are recorded and shown under the findings; the scan continues.
3. **Severity and advice now come from one place** (`scanner/rules.py`) so the code, Chapter 2 Table 2.1 and Chapter 3 all use the same 13 rules and three levels.

## New checks

- EC2 security groups: SSH (22) and RDP (3389) open to 0.0.0.0/0 or ::/0, including "all traffic" rules.
- IAM: root MFA, console users without MFA, full admin policies (managed and inline, on users, groups and roles), access keys older than 90 days.
- CloudTrail: no trail logging, log file validation off.
- EBS: encryption by default off, unencrypted volumes. (S3 encryption is automatic since January 2023, so an S3 encryption check would always pass.)

## New features for the evaluation

- **Scan time** is measured for the whole scan and for each module (detection response time, Td = Te − Ts).
- **Scan history** page and **CSV export** of findings.
- **`evaluation/evaluate.py`** calculates TP, FP, FN, TN, accuracy, precision, recall, F1-score and false positive rate from a ground-truth file.
- **Offline tests** (`tests/test_scanners.py`) use `moto` to imitate AWS, create misconfigured and secure resources, and check that each rule fires only where it should. 11 tests pass.

## Removed

- `reportlab` (installed but never used). PDF export can be added later if needed.
